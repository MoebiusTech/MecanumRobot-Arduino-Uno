#ifndef __CONFIG_H__
#define __CONFIG_H__

#define PID_EN 1
#define MOTOR_REVERSE 0
#define ENCODER_REVERSE 0

#endif
