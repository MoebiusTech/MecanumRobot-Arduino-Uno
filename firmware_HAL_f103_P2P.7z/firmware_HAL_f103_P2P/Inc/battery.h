#ifndef __BATTERY_H__
#define __BATTERY_H__

#include "motor.h"

#define HADC hadc1
#define BAT_TH 2100//2000//2171//7v=3.5v*2=1.75v*4 1.75/3.3*4095
#define BAT_PERIOD 200

uint8_t Check_volt(uint16_t *volt);

#endif
